-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2016 at 04:01 AM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `daddy-day-care`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `account_id` int(12) NOT NULL,
  `account_balance` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `accountlinks`
--

CREATE TABLE IF NOT EXISTS `accountlinks` (
  `link_id` int(12) NOT NULL,
  `account_id` int(12) NOT NULL,
  `guardian_id` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `allowedpickup`
--

CREATE TABLE IF NOT EXISTS `allowedpickup` (
  `allowed_id` int(12) NOT NULL,
  `guardian_id` int(12) NOT NULL,
  `child_id` int(12) NOT NULL,
  `guardian_relationship` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE IF NOT EXISTS `billing` (
  `billing_id` int(12) NOT NULL,
  `billing_date` varchar(10) NOT NULL,
  `billing_due` varchar(10) NOT NULL,
  `account_id` int(12) NOT NULL,
  `billing_amount` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `child`
--

CREATE TABLE IF NOT EXISTS `child` (
  `child_id` int(12) NOT NULL,
  `child_name` varchar(50) NOT NULL,
  `teacher_id` int(12) NOT NULL,
  `child_address` varchar(100) NOT NULL,
  `child_zip` int(5) NOT NULL,
  `child_gender` enum('male','female','other') NOT NULL,
  `child_hair` varchar(32) NOT NULL,
  `child_eyes` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dailypickup`
--

CREATE TABLE IF NOT EXISTS `dailypickup` (
  `pickup_id` int(12) NOT NULL,
  `pickup_relationship1` varchar(32) NOT NULL,
  `pickup_relationship2` varchar(32) NOT NULL,
  `pickup_start` varchar(10) NOT NULL,
  `pickup_end` varchar(10) NOT NULL,
  `child_id` int(12) NOT NULL,
  `guardian1_id` int(12) NOT NULL,
  `guardian2_id` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty_id` int(12) NOT NULL,
  `faculty_name` varchar(50) NOT NULL,
  `faculty_address` varchar(100) NOT NULL,
  `faculty_zip` int(5) NOT NULL,
  `faculty_phone` varchar(10) NOT NULL,
  `faculty_gender` enum('male','female','other') NOT NULL,
  `faculty_wage` varchar(32) NOT NULL,
  `faculty_position` varchar(64) NOT NULL,
  `faculty_wageType` enum('salary','hourly') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guardian`
--

CREATE TABLE IF NOT EXISTS `guardian` (
  `guardian_id` int(12) NOT NULL,
  `guardian_name` varchar(50) NOT NULL,
  `guardian_address` varchar(100) NOT NULL,
  `guardian_zip` int(5) NOT NULL,
  `guardian_phone` varchar(10) NOT NULL,
  `guardian_gender` enum('male','female','other') NOT NULL,
  `guardian_hair` varchar(32) NOT NULL,
  `guardian_eyes` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `user_id` int(12) NOT NULL,
  `username` varchar(35) NOT NULL,
  `user_password` varchar(40) NOT NULL,
  `login_hash` varchar(32) NOT NULL,
  `login_created` varchar(10) NOT NULL,
  `login_type` enum('faculty','guardian') NOT NULL,
  `user_accType` enum('faculty','parent') NOT NULL,
  `user_timestamp` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE IF NOT EXISTS `medicine` (
  `medicine_id` int(12) NOT NULL,
  `medicine_name` varchar(32) NOT NULL,
  `medicine_freqency` int(5) NOT NULL,
  `medicine_freqType` enum('hourly','daily','weekly') NOT NULL,
  `medicine_amount` varchar(10) NOT NULL,
  `child_id` int(12) NOT NULL,
  `teacher_id` int(12) NOT NULL,
  `medicine_purpose` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `payment_id` int(12) NOT NULL,
  `payment_type` enum('cash','check','debit','credit') NOT NULL,
  `account_id` int(12) NOT NULL,
  `guardian_id` int(12) NOT NULL,
  `payment_amount` float NOT NULL,
  `payment_date` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `paymentcard`
--

CREATE TABLE IF NOT EXISTS `paymentcard` (
  `card_id` int(12) NOT NULL,
  `card_number` int(16) NOT NULL,
  `card_ccv` int(4) NOT NULL,
  `card_carrier` enum('visa','mastercard','amex','discover') NOT NULL,
  `account_id` int(12) NOT NULL,
  `guardian_id` int(12) NOT NULL,
  `card_transaction` enum('debit','credit') NOT NULL,
  `card_exp` int(4) NOT NULL,
  `card_Autopay` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `paymentcheck`
--

CREATE TABLE IF NOT EXISTS `paymentcheck` (
  `check_id` int(12) NOT NULL,
  `check_routing` int(9) NOT NULL,
  `check_account` int(12) NOT NULL,
  `account_id` int(12) NOT NULL,
  `guardian_id` int(12) NOT NULL,
  `check_received` varchar(10) NOT NULL,
  `check_confirmed` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `teacher_id` int(12) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `teacher_address` varchar(100) NOT NULL,
  `teacher_zip` int(5) NOT NULL,
  `teacher_phone` varchar(10) NOT NULL,
  `teacher_position` varchar(64) NOT NULL,
  `teacher_gender` enum('male','female','other') NOT NULL,
  `teacher_wage` varchar(32) NOT NULL,
  `teacher_wageType` enum('salary','hourly') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `accountlinks`
--
ALTER TABLE `accountlinks`
  ADD PRIMARY KEY (`link_id`);

--
-- Indexes for table `allowedpickup`
--
ALTER TABLE `allowedpickup`
  ADD PRIMARY KEY (`allowed_id`);

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`billing_id`);

--
-- Indexes for table `child`
--
ALTER TABLE `child`
  ADD PRIMARY KEY (`child_id`);

--
-- Indexes for table `dailypickup`
--
ALTER TABLE `dailypickup`
  ADD PRIMARY KEY (`pickup_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `guardian`
--
ALTER TABLE `guardian`
  ADD PRIMARY KEY (`guardian_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`medicine_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `paymentcard`
--
ALTER TABLE `paymentcard`
  ADD PRIMARY KEY (`card_id`);

--
-- Indexes for table `paymentcheck`
--
ALTER TABLE `paymentcheck`
  ADD PRIMARY KEY (`check_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `account_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `accountlinks`
--
ALTER TABLE `accountlinks`
  MODIFY `link_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `allowedpickup`
--
ALTER TABLE `allowedpickup`
  MODIFY `allowed_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `billing_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `child`
--
ALTER TABLE `child`
  MODIFY `child_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `dailypickup`
--
ALTER TABLE `dailypickup`
  MODIFY `pickup_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `faculty_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `guardian`
--
ALTER TABLE `guardian`
  MODIFY `guardian_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `user_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `medicine_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `paymentcard`
--
ALTER TABLE `paymentcard`
  MODIFY `card_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `paymentcheck`
--
ALTER TABLE `paymentcheck`
  MODIFY `check_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(12) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
