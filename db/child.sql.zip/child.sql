-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2016 at 04:10 AM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `daddy-day-care`
--

-- --------------------------------------------------------

--
-- Table structure for table `child`
--

CREATE TABLE IF NOT EXISTS `child` (
  `child_id` int(12) NOT NULL,
  `child_name` varchar(50) NOT NULL,
  `teacher_id` int(12) NOT NULL,
  `child_address` varchar(100) NOT NULL,
  `child_zip` int(5) NOT NULL,
  `child_gender` enum('male','female','other') NOT NULL,
  `child_hair` varchar(32) NOT NULL,
  `child_eyes` varchar(32) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `child`
--

INSERT INTO `child` (`child_id`, `child_name`, `teacher_id`, `child_address`, `child_zip`, `child_gender`, `child_hair`, `child_eyes`) VALUES
(1, 'Biggy Smalls', 1, '1234 sticky balls st. apt 4 ', 12345, 'male', 'white', 'red'),
(2, 'samatha tities', 1, '12345 W coffee St.', 12345, 'other', 'brown', 'blue'),
(3, 'Mouse trap', 1, '5555 E boobies St. ', 12345, 'male', 'Red', 'black'),
(4, 'Sticky hair', 1, '6586 S BoysRmen ave', 12345, 'female', 'yelllow', 'white'),
(5, 'itachi uchia', 1, '9999 N KickurAss Ave', 12345, 'male', 'black', 'brown');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `child`
--
ALTER TABLE `child`
  ADD PRIMARY KEY (`child_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `child`
--
ALTER TABLE `child`
  MODIFY `child_id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
